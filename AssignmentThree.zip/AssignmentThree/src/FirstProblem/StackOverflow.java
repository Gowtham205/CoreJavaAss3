package FirstProblem;

public class StackOverflow {

	public static void main(String[] args) {

			met1();
	}

	public static void met1() {
		System.out.println("Im there");
		met1();
	}
}
